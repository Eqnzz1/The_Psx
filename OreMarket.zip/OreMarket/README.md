# OreMarket Plugin — Setup Guide (Hinglish)

Ye plugin Minecraft mining ko stock market se mix karta hai. Coding samajhna
zaroori nahi hai bas neeche diye steps follow karo.

## Kya kya milega isme
- 30 ores/items = 30 "stocks", 3 tier mein baante hue: **common**, **rare**, **best**
- Har tier ka apna **index** (average price)
- Price real market ki tarah upar-niche hoti hai (buy/sell pressure se)
- Ore mine karne pe cash milta hai (jitna rare, utna zyada)
- Kill karne pe victim ke saare stocks tumhe mil jaate hain
- Commands: `/orestock portfolio`, `/orestock market`, `/orestock buy`,
  `/orestock sell`, `/orestock chart`, `/orestock trade`, `/orestock give`

**Note:** Tumne "double-click se chart khule" bola tha — Minecraft mein
double-click reliably detect nahi hoti (game engine support nahi karta),
isliye maine **normal click = 1 share buy** aur **shift+click = chart open**
rakha hai market GUI mein. `/orestock chart <ore>` se bhi kabhi bhi chart
dekh sakte ho.

## Step 1: Software install karo (ek baar ka kaam)
1. **Java 17** install karo (JDK): https://adoptium.net (Temurin 17 download karo)
2. **IntelliJ IDEA Community Edition** install karo (free): https://www.jetbrains.com/idea/download
   - Ye ek app hai jisme code "build" hota hai — tumhe khud code likhna nahi hai,
     bas button dabana hai.

## Step 2: Project kholo
1. Ye poora `OreMarket` folder apne computer pe rakho (jo maine banaya hai)
2. IntelliJ kholo → **Open** → is `OreMarket` folder ko select karo
3. IntelliJ khud-ba-khud internet se zaroori files (Paper API) download karega
   — thoda wait karo, neeche progress bar dikhega, complete hone do
   (isliye tumhare computer mein internet on hona chahiye)

## Step 3: Build karo (.jar file banao)
1. IntelliJ ke right side mein **Maven** tab dhoondo (ya View → Tool Windows → Maven)
2. `OreMarket` → `Lifecycle` → **package** pe double-click karo
3. Neeche "BUILD SUCCESS" likha aayega
4. File ban jayegi yahan: `target/OreMarket.jar`

## Step 4: Server pe daalo
1. `OreMarket.jar` file ko apne Minecraft **Paper/Spigot server** ke
   `plugins` folder mein copy-paste karo
2. Server restart karo
3. Ek naya folder banega: `plugins/OreMarket/config.yml` — isme tum
   prices, ores, tiers **bina coding ke** edit kar sakte ho (text file hai,
   Notepad se khol lo)

## Zaroori baat
- Tumhare Minecraft server ko **Paper** ya **Spigot** hona chahiye
  (normal vanilla server pe plugins kaam nahi karte). Agar abhi vanilla
  server hai, bata do — kaise Paper pe switch karna hai wo bhi bata dunga.
- Server version 1.20.x rakhna (config isi ke liye banaya hai)

## Config customize karna (coding ke bina)
`plugins/OreMarket/config.yml` file kholo, isme:
- `base-price` badal ke koi bhi ore ki starting price change kar sakte ho
- `tier: common/rare/best` badal ke stock ko dusre index mein daal sakte ho
- `starting-balance` se naye player ka starting cash set karo
- `mining-reward-percent` se decide karo mining se kitna % milega

Change karne ke baad `/reload confirm` chalao ya server restart karo.

---
Koi bhi step atke, ya koi error aaye screenshot bhej dena, main help kar dunga.
