package com.orestock;

import com.orestock.commands.OreStockCommand;
import com.orestock.listeners.DeathListener;
import com.orestock.listeners.GUIClickListener;
import com.orestock.listeners.JoinListener;
import com.orestock.listeners.MiningListener;
import com.orestock.market.MarketManager;
import com.orestock.player.AccountManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class OreMarketPlugin extends JavaPlugin {

    private MarketManager marketManager;
    private AccountManager accountManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.marketManager = new MarketManager(this);
        this.accountManager = new AccountManager(this);

        // Commands
        OreStockCommand command = new OreStockCommand(this);
        getCommand("orestock").setExecutor(command);
        getCommand("orestock").setTabCompleter(command);

        // Listeners
        Bukkit.getPluginManager().registerEvents(new MiningListener(this), this);
        Bukkit.getPluginManager().registerEvents(new DeathListener(this), this);
        Bukkit.getPluginManager().registerEvents(new JoinListener(this), this);
        Bukkit.getPluginManager().registerEvents(new GUIClickListener(this), this);

        // Price update task - config mein set kiya gaya interval use karta hai
        int interval = getConfig().getInt("price-update-interval-seconds", 30);
        Bukkit.getScheduler().runTaskTimer(this, marketManager::tick, interval * 20L, interval * 20L);

        // Har 5 minute mein auto-save (crash se data bachane ke liye)
        Bukkit.getScheduler().runTaskTimer(this, accountManager::saveAll, 6000L, 6000L);

        getLogger().info("OreMarket plugin enabled! " + marketManager.getAll().size() + " stocks loaded.");
    }

    @Override
    public void onDisable() {
        if (accountManager != null) {
            accountManager.saveAll();
        }
        getLogger().info("OreMarket plugin disabled, data saved.");
    }

    public MarketManager getMarketManager() { return marketManager; }
    public AccountManager getAccountManager() { return accountManager; }
}
