package com.orestock.commands;

import com.orestock.OreMarketPlugin;
import com.orestock.gui.ChartGUI;
import com.orestock.gui.MarketGUI;
import com.orestock.market.MarketManager;
import com.orestock.market.OreStock;
import com.orestock.player.AccountManager;
import com.orestock.player.PlayerAccount;
import org.bukkit.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;

public class OreStockCommand implements CommandExecutor, TabCompleter {

    private final OreMarketPlugin plugin;
    private final MarketManager market;
    private final AccountManager accounts;

    // pending trade requests: target UUID -> [fromUUID, oreKey, amount]
    private final Map<UUID, PendingTrade> pendingTrades = new HashMap<>();

    public OreStockCommand(OreMarketPlugin plugin) {
        this.plugin = plugin;
        this.market = plugin.getMarketManager();
        this.accounts = plugin.getAccountManager();
    }

    private static class PendingTrade {
        UUID from;
        String oreKey;
        int amount;
        PendingTrade(UUID from, String oreKey, int amount) {
            this.from = from; this.oreKey = oreKey; this.amount = amount;
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Ye command sirf players use kar sakte hain.");
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        String sub = args[0].toLowerCase();
        switch (sub) {
            case "portfolio" -> handlePortfolio(player);
            case "market" -> MarketGUI.open(player, market, "common");
            case "buy" -> handleBuy(player, args);
            case "sell" -> handleSell(player, args);
            case "chart" -> handleChart(player, args);
            case "trade" -> handleTrade(player, args);
            case "accept" -> handleAccept(player);
            case "give" -> handleGive(player, args);
            default -> sendHelp(player);
        }
        return true;
    }

    private void sendHelp(Player player) {
        player.sendMessage(ChatColor.GOLD + "===== OreMarket Commands =====");
        player.sendMessage(ChatColor.YELLOW + "/orestock portfolio" + ChatColor.GRAY + " - apna balance aur shares dekho");
        player.sendMessage(ChatColor.YELLOW + "/orestock market" + ChatColor.GRAY + " - market GUI kholo");
        player.sendMessage(ChatColor.YELLOW + "/orestock buy <ore> <amount>" + ChatColor.GRAY + " - shares kharido");
        player.sendMessage(ChatColor.YELLOW + "/orestock sell <ore> <amount>" + ChatColor.GRAY + " - shares becho");
        player.sendMessage(ChatColor.YELLOW + "/orestock chart <ore>" + ChatColor.GRAY + " - price chart dekho");
        player.sendMessage(ChatColor.YELLOW + "/orestock trade <player> <ore> <amount>" + ChatColor.GRAY + " - trade offer bhejo");
        player.sendMessage(ChatColor.YELLOW + "/orestock accept" + ChatColor.GRAY + " - pending trade accept karo");
        player.sendMessage(ChatColor.YELLOW + "/orestock give <player> <ore> <amount>" + ChatColor.GRAY + " - shares free mein do");
    }

    private void handlePortfolio(Player player) {
        PlayerAccount account = accounts.getAccount(player.getUniqueId());
        player.sendMessage(ChatColor.GOLD + "===== " + player.getName() + "'s Portfolio =====");
        player.sendMessage(ChatColor.GREEN + "Cash: $" + String.format("%.2f", account.getBalance()));

        double netWorth = account.getBalance();
        if (account.getPortfolio().isEmpty()) {
            player.sendMessage(ChatColor.GRAY + "Koi shares nahi hain abhi.");
        } else {
            for (Map.Entry<String, Integer> entry : account.getPortfolio().entrySet()) {
                OreStock stock = market.get(entry.getKey());
                if (stock == null) continue;
                double value = stock.getCurrentPrice() * entry.getValue();
                netWorth += value;
                player.sendMessage(ChatColor.AQUA + stock.getDisplayName() + ChatColor.WHITE + ": " + entry.getValue()
                        + ChatColor.GRAY + " shares (worth $" + String.format("%.2f", value) + ")");
            }
        }
        player.sendMessage(ChatColor.YELLOW + "Net Worth: $" + String.format("%.2f", netWorth));
    }

    private void handleBuy(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(ChatColor.RED + "Use: /orestock buy <ore> <amount>");
            return;
        }
        OreStock stock = market.get(args[1]);
        if (stock == null) {
            player.sendMessage(ChatColor.RED + "Ye ore stock exist nahi karta.");
            return;
        }
        int amount = parseAmount(player, args[2]);
        if (amount <= 0) return;

        PlayerAccount account = accounts.getAccount(player.getUniqueId());
        double cost = stock.getCurrentPrice() * amount;

        if (!account.removeBalance(cost)) {
            player.sendMessage(ChatColor.RED + "Paise kam hain! Chahiye: $" + String.format("%.2f", cost)
                    + ", tumhare paas: $" + String.format("%.2f", account.getBalance()));
            return;
        }

        account.addShares(stock.getKey(), amount);
        stock.addBuyVolume(amount);
        player.sendMessage(ChatColor.GREEN + "Kharida: " + amount + "x " + stock.getDisplayName()
                + " for $" + String.format("%.2f", cost));
    }

    private void handleSell(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(ChatColor.RED + "Use: /orestock sell <ore> <amount>");
            return;
        }
        OreStock stock = market.get(args[1]);
        if (stock == null) {
            player.sendMessage(ChatColor.RED + "Ye ore stock exist nahi karta.");
            return;
        }
        int amount = parseAmount(player, args[2]);
        if (amount <= 0) return;

        PlayerAccount account = accounts.getAccount(player.getUniqueId());
        if (!account.removeShares(stock.getKey(), amount)) {
            player.sendMessage(ChatColor.RED + "Itne shares nahi hain tumhare paas.");
            return;
        }

        double revenue = stock.getCurrentPrice() * amount;
        account.addBalance(revenue);
        stock.addSellVolume(amount);
        player.sendMessage(ChatColor.GREEN + "Becha: " + amount + "x " + stock.getDisplayName()
                + " for $" + String.format("%.2f", revenue));
    }

    private void handleChart(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(ChatColor.RED + "Use: /orestock chart <ore>");
            return;
        }
        OreStock stock = market.get(args[1]);
        if (stock == null) {
            player.sendMessage(ChatColor.RED + "Ye ore stock exist nahi karta.");
            return;
        }
        ChartGUI.open(player, stock);
    }

    private void handleTrade(Player player, String[] args) {
        if (args.length < 4) {
            player.sendMessage(ChatColor.RED + "Use: /orestock trade <player> <ore> <amount>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "Wo player online nahi hai.");
            return;
        }
        OreStock stock = market.get(args[2]);
        if (stock == null) {
            player.sendMessage(ChatColor.RED + "Ye ore stock exist nahi karta.");
            return;
        }
        int amount = parseAmount(player, args[3]);
        if (amount <= 0) return;

        PlayerAccount account = accounts.getAccount(player.getUniqueId());
        if (account.getShares(stock.getKey()) < amount) {
            player.sendMessage(ChatColor.RED + "Itne shares nahi hain tumhare paas.");
            return;
        }

        pendingTrades.put(target.getUniqueId(), new PendingTrade(player.getUniqueId(), stock.getKey(), amount));
        player.sendMessage(ChatColor.GREEN + "Trade offer bheja: " + amount + "x " + stock.getDisplayName() + " to " + target.getName());
        target.sendMessage(ChatColor.GOLD + player.getName() + " ne offer kiya hai: " + amount + "x " + stock.getDisplayName()
                + ChatColor.GRAY + " (/orestock accept se accept karo)");
    }

    private void handleAccept(Player player) {
        PendingTrade trade = pendingTrades.remove(player.getUniqueId());
        if (trade == null) {
            player.sendMessage(ChatColor.RED + "Koi pending trade nahi hai tumhare liye.");
            return;
        }
        Player fromPlayer = Bukkit.getPlayer(trade.from);
        PlayerAccount fromAccount = accounts.getAccount(trade.from);

        if (fromAccount.getShares(trade.oreKey) < trade.amount) {
            player.sendMessage(ChatColor.RED + "Trade fail: sender ke paas ab itne shares nahi hain.");
            return;
        }

        fromAccount.removeShares(trade.oreKey, trade.amount);
        accounts.getAccount(player.getUniqueId()).addShares(trade.oreKey, trade.amount);

        OreStock stock = market.get(trade.oreKey);
        String stockName = stock != null ? stock.getDisplayName() : trade.oreKey;

        player.sendMessage(ChatColor.GREEN + "Trade accept ho gaya: " + trade.amount + "x " + stockName + " mil gaye!");
        if (fromPlayer != null) {
            fromPlayer.sendMessage(ChatColor.GREEN + player.getName() + " ne tumhara trade accept kar liya.");
        }
    }

    private void handleGive(Player player, String[] args) {
        if (args.length < 4) {
            player.sendMessage(ChatColor.RED + "Use: /orestock give <player> <ore> <amount>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "Wo player online nahi hai.");
            return;
        }
        OreStock stock = market.get(args[2]);
        if (stock == null) {
            player.sendMessage(ChatColor.RED + "Ye ore stock exist nahi karta.");
            return;
        }
        int amount = parseAmount(player, args[3]);
        if (amount <= 0) return;

        PlayerAccount account = accounts.getAccount(player.getUniqueId());
        if (!account.removeShares(stock.getKey(), amount)) {
            player.sendMessage(ChatColor.RED + "Itne shares nahi hain tumhare paas.");
            return;
        }

        accounts.getAccount(target.getUniqueId()).addShares(stock.getKey(), amount);
        player.sendMessage(ChatColor.GREEN + "" + amount + "x " + stock.getDisplayName() + " de diye " + target.getName() + " ko.");
        target.sendMessage(ChatColor.GREEN + player.getName() + " ne tumhe " + amount + "x " + stock.getDisplayName() + " diye.");
    }

    private int parseAmount(Player player, String raw) {
        try {
            int amount = Integer.parseInt(raw);
            if (amount <= 0) {
                player.sendMessage(ChatColor.RED + "Amount 0 se zyada hona chahiye.");
                return -1;
            }
            return amount;
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "Amount ek number hona chahiye.");
            return -1;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(List.of("portfolio", "market", "buy", "sell", "chart", "trade", "accept", "give", "help"), args[0]);
        }
        if (args.length == 2 && List.of("buy", "sell", "chart").contains(args[0].toLowerCase())) {
            List<String> keys = new ArrayList<>();
            for (OreStock s : market.getAll()) keys.add(s.getKey());
            return filter(keys, args[1]);
        }
        if (args.length == 2 && List.of("trade", "give").contains(args[0].toLowerCase())) {
            List<String> names = new ArrayList<>();
            for (Player p : Bukkit.getOnlinePlayers()) names.add(p.getName());
            return filter(names, args[1]);
        }
        if (args.length == 3 && List.of("trade", "give").contains(args[0].toLowerCase())) {
            List<String> keys = new ArrayList<>();
            for (OreStock s : market.getAll()) keys.add(s.getKey());
            return filter(keys, args[2]);
        }
        return Collections.emptyList();
    }

    private List<String> filter(List<String> options, String input) {
        List<String> result = new ArrayList<>();
        for (String o : options) {
            if (o.toLowerCase().startsWith(input.toLowerCase())) result.add(o);
        }
        return result;
    }
}
