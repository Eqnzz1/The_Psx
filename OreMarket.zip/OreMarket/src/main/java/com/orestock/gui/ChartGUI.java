package com.orestock.gui;

import com.orestock.market.OreStock;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.LinkedList;

public class ChartGUI {

    public static final String TITLE_PREFIX = ChatColor.DARK_AQUA + "Chart: ";

    public static void open(Player player, OreStock stock) {
        Inventory inv = Bukkit.createInventory(null, 54, TITLE_PREFIX + stock.getDisplayName());

        LinkedList<Double> history = stock.getHistory();
        int columns = 9;
        int rows = 6;

        double min = history.stream().mapToDouble(Double::doubleValue).min().orElse(0);
        double max = history.stream().mapToDouble(Double::doubleValue).max().orElse(1);
        if (max == min) max = min + 1; // divide by zero se bachne ke liye

        // last N points lo (max = columns)
        int startIdx = Math.max(0, history.size() - columns);
        int col = 0;
        for (int i = startIdx; i < history.size(); i++) {
            double price = history.get(i);
            int filledRows = (int) Math.round(((price - min) / (max - min)) * (rows - 1)) + 1;

            for (int r = 0; r < rows; r++) {
                int slot = (rows - 1 - r) * 9 + col;
                Material mat;
                if (r < filledRows) {
                    // sabse upar wala filled block = current bar ka top -> green agar last point se zyada, red agar kam
                    mat = Material.LIME_STAINED_GLASS_PANE;
                } else {
                    mat = Material.GRAY_STAINED_GLASS_PANE;
                }
                ItemStack pane = new ItemStack(mat);
                ItemMeta meta = pane.getItemMeta();
                meta.setDisplayName(ChatColor.WHITE + "$" + String.format("%.2f", price));
                pane.setItemMeta(meta);
                inv.setItem(slot, pane);
            }
            col++;
        }

        ItemStack info = new ItemStack(Material.NAME_TAG);
        ItemMeta infoMeta = info.getItemMeta();
        infoMeta.setDisplayName(ChatColor.GOLD + stock.getDisplayName() + ChatColor.GRAY + " (" + stock.getTier() + ")");
        infoMeta.setLore(java.util.List.of(
                ChatColor.GREEN + "Current: $" + String.format("%.2f", stock.getCurrentPrice()),
                ChatColor.YELLOW + "High: $" + String.format("%.2f", max),
                ChatColor.RED + "Low: $" + String.format("%.2f", min)
        ));
        info.setItemMeta(infoMeta);
        inv.setItem(49, info);

        player.openInventory(inv);
    }
}
