package com.orestock.gui;

import com.orestock.market.MarketManager;
import com.orestock.market.OreStock;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/**
 * Market GUI teen "pages" mein bata hai (tier ke hisaab se).
 * Title mein tier ka naam encode hota hai taaki click listener samajh sake.
 */
public class MarketGUI {

    public static final String TITLE_PREFIX = ChatColor.DARK_GREEN + "Ore Market: ";

    public static void open(Player player, MarketManager market, String tier) {
        Inventory inv = Bukkit.createInventory(null, 54, TITLE_PREFIX + capitalize(tier));

        List<OreStock> stocks = market.getByTier(tier);
        int slot = 10;
        for (OreStock stock : stocks) {
            if (slot % 9 == 8) slot += 2; // border se bachne ke liye
            inv.setItem(slot, buildItem(stock));
            slot++;
        }

        // Navigation items (bottom row)
        inv.setItem(45, navItem(Material.COAL, "Index Common 10", "common"));
        inv.setItem(46, navItem(Material.GOLD_INGOT, "Index Rare 10", "rare"));
        inv.setItem(47, navItem(Material.DIAMOND, "Index Best 10", "best"));

        ItemStack info = new ItemStack(Material.PAPER);
        ItemMeta infoMeta = info.getItemMeta();
        infoMeta.setDisplayName(ChatColor.YELLOW + "Index Average: " + ChatColor.WHITE + "$" + String.format("%.2f", market.getIndexAverage(tier)));
        info.setItemMeta(infoMeta);
        inv.setItem(49, info);

        player.openInventory(inv);
    }

    private static ItemStack navItem(Material material, String label, String tierKey) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + label);
        meta.setLore(List.of(ChatColor.GRAY + "Click to view", ChatColor.DARK_GRAY + "tier:" + tierKey));
        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack buildItem(OreStock stock) {
        ItemStack item = new ItemStack(stock.getMaterial());
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.GOLD + stock.getDisplayName() + ChatColor.GRAY + " [" + stock.getKey() + "]");
        meta.setLore(List.of(
                ChatColor.GREEN + "Price: $" + String.format("%.2f", stock.getCurrentPrice()),
                ChatColor.DARK_GRAY + "Base: $" + String.format("%.2f", stock.getBasePrice()),
                ChatColor.YELLOW + "Click: buy 1  |  Shift-Click: chart",
                ChatColor.DARK_GRAY + "key:" + stock.getKey()
        ));
        item.setItemMeta(meta);
        return item;
    }

    private static String capitalize(String s) {
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }
}
