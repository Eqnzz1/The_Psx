package com.orestock.listeners;

import com.orestock.OreMarketPlugin;
import com.orestock.player.AccountManager;
import com.orestock.player.PlayerAccount;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.util.Map;

public class DeathListener implements Listener {

    private final AccountManager accounts;

    public DeathListener(OreMarketPlugin plugin) {
        this.accounts = plugin.getAccountManager();
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        if (killer == null) return; // fall damage, mobs etc se stocks nahi milte

        PlayerAccount victimAccount = accounts.getAccount(victim.getUniqueId());
        PlayerAccount killerAccount = accounts.getAccount(killer.getUniqueId());

        if (victimAccount.getPortfolio().isEmpty()) {
            killer.sendMessage(ChatColor.GRAY + victim.getName() + " ke paas koi stocks nahi the.");
            return;
        }

        for (Map.Entry<String, Integer> entry : victimAccount.getPortfolio().entrySet()) {
            killerAccount.addShares(entry.getKey(), entry.getValue());
        }
        victimAccount.clearPortfolio();

        killer.sendMessage(ChatColor.GOLD + victim.getName() + " ke saare stocks tumhe mil gaye!");
        victim.sendMessage(ChatColor.RED + "Tumhare saare stocks " + killer.getName() + " ko chale gaye!");
    }
}
