package com.orestock.listeners;

import com.orestock.OreMarketPlugin;
import com.orestock.gui.ChartGUI;
import com.orestock.gui.MarketGUI;
import com.orestock.market.MarketManager;
import com.orestock.market.OreStock;
import com.orestock.player.AccountManager;
import com.orestock.player.PlayerAccount;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class GUIClickListener implements Listener {

    private final MarketManager market;
    private final AccountManager accounts;

    public GUIClickListener(OreMarketPlugin plugin) {
        this.market = plugin.getMarketManager();
        this.accounts = plugin.getAccountManager();
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        String title = event.getView().getTitle();
        if (title.startsWith(ChatColor.stripColor(MarketGUI.TITLE_PREFIX)) || title.startsWith(MarketGUI.TITLE_PREFIX)) {
            handleMarketClick(event);
        } else if (title.startsWith(ChatColor.stripColor(ChartGUI.TITLE_PREFIX)) || title.startsWith(ChartGUI.TITLE_PREFIX)) {
            event.setCancelled(true); // chart sirf dekhne ke liye hai
        }
    }

    private void handleMarketClick(InventoryClickEvent event) {
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType().isAir()) return;
        ItemMeta meta = clicked.getItemMeta();
        if (meta == null || meta.getLore() == null) return;

        List<String> lore = meta.getLore();

        // Navigation item hai kya (tier switch)?
        for (String line : lore) {
            if (line.startsWith(ChatColor.DARK_GRAY + "tier:")) {
                String tier = line.substring((ChatColor.DARK_GRAY + "tier:").length());
                MarketGUI.open(player, market, tier);
                return;
            }
        }

        // stock item hai kya?
        String oreKey = null;
        for (String line : lore) {
            if (line.startsWith(ChatColor.DARK_GRAY + "key:")) {
                oreKey = line.substring((ChatColor.DARK_GRAY + "key:").length());
            }
        }
        if (oreKey == null) return;

        OreStock stock = market.get(oreKey);
        if (stock == null) return;

        if (event.isShiftClick()) {
            ChartGUI.open(player, stock);
            return;
        }

        // normal click = 1 share buy karo
        PlayerAccount account = accounts.getAccount(player.getUniqueId());
        double price = stock.getCurrentPrice();
        if (!account.removeBalance(price)) {
            player.sendMessage(ChatColor.RED + "Paise kam hain 1 share ke liye ($" + String.format("%.2f", price) + ")");
            return;
        }
        account.addShares(stock.getKey(), 1);
        stock.addBuyVolume(1);
        player.sendMessage(ChatColor.GREEN + "1x " + stock.getDisplayName() + " khareed liya for $" + String.format("%.2f", price));

        // GUI refresh karo taaki naya price/lore dikhe
        MarketGUI.open(player, market, stock.getTier());
    }
}
