package com.orestock.listeners;

import com.orestock.OreMarketPlugin;
import com.orestock.player.AccountManager;
import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class JoinListener implements Listener {

    private final AccountManager accounts;

    public JoinListener(OreMarketPlugin plugin) {
        this.accounts = plugin.getAccountManager();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        boolean isNew = !accounts.isLoaded(event.getPlayer().getUniqueId());
        var account = accounts.getAccount(event.getPlayer().getUniqueId());
        if (isNew) {
            event.getPlayer().sendMessage(ChatColor.GOLD + "Welcome to OreMarket! Tumhe mile $"
                    + String.format("%.2f", account.getBalance()) + " starting cash.");
            event.getPlayer().sendMessage(ChatColor.GRAY + "/orestock help likh ke commands dekho.");
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        accounts.saveAccount(event.getPlayer().getUniqueId());
    }
}
