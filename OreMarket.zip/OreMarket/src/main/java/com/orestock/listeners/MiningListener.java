package com.orestock.listeners;

import com.orestock.OreMarketPlugin;
import com.orestock.market.MarketManager;
import com.orestock.market.OreStock;
import com.orestock.player.AccountManager;
import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;

public class MiningListener implements Listener {

    private final MarketManager market;
    private final AccountManager accounts;

    public MiningListener(OreMarketPlugin plugin) {
        this.market = plugin.getMarketManager();
        this.accounts = plugin.getAccountManager();
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (event.isCancelled()) return;

        OreStock stock = market.getBySourceBlock(event.getBlock().getType());
        if (stock == null) return;

        double reward = stock.getCurrentPrice() * market.getMiningRewardPercent();
        accounts.getAccount(event.getPlayer().getUniqueId()).addBalance(reward);

        event.getPlayer().sendActionBar(ChatColor.GREEN + "+$" + String.format("%.2f", reward)
                + ChatColor.GRAY + " (" + stock.getDisplayName() + " mined)");
    }
}
