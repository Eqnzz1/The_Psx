package com.orestock.market;

import com.orestock.OreMarketPlugin;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

import java.util.*;
import java.util.stream.Collectors;

public class MarketManager {

    private final OreMarketPlugin plugin;
    private final Map<String, OreStock> stocks = new LinkedHashMap<>();
    private final Map<String, Double> volatilityByTier = new HashMap<>();
    private int historyLength;
    private double miningRewardPercent;

    public MarketManager(OreMarketPlugin plugin) {
        this.plugin = plugin;
        loadFromConfig();
    }

    public void loadFromConfig() {
        stocks.clear();
        var config = plugin.getConfig();

        historyLength = config.getInt("history-length", 30);
        miningRewardPercent = config.getDouble("mining-reward-percent", 0.05);

        volatilityByTier.put("common", config.getDouble("volatility.common", 0.03));
        volatilityByTier.put("rare", config.getDouble("volatility.rare", 0.06));
        volatilityByTier.put("best", config.getDouble("volatility.best", 0.10));

        ConfigurationSection oresSection = config.getConfigurationSection("ores");
        if (oresSection == null) return;

        for (String key : oresSection.getKeys(false)) {
            ConfigurationSection ore = oresSection.getConfigurationSection(key);
            if (ore == null) continue;

            String displayName = ore.getString("display-name", key);
            String materialName = ore.getString("material", "STONE");
            String sourceBlockName = ore.getString("source-block", null);
            String tier = ore.getString("tier", "common");
            double basePrice = ore.getDouble("base-price", 50.0);

            Material material = Material.matchMaterial(materialName);
            if (material == null) material = Material.STONE;

            Material sourceBlock = null;
            if (sourceBlockName != null && !sourceBlockName.equalsIgnoreCase("null")) {
                sourceBlock = Material.matchMaterial(sourceBlockName);
            }

            OreStock stock = new OreStock(key, displayName, material, sourceBlock, tier, basePrice, historyLength);
            stocks.put(key, stock);
        }
    }

    public OreStock get(String key) {
        return stocks.get(key.toUpperCase());
    }

    public Collection<OreStock> getAll() {
        return stocks.values();
    }

    public List<OreStock> getByTier(String tier) {
        return stocks.values().stream()
                .filter(s -> s.getTier().equalsIgnoreCase(tier))
                .sorted(Comparator.comparingDouble(OreStock::getCurrentPrice).reversed())
                .collect(Collectors.toList());
    }

    public OreStock getBySourceBlock(Material block) {
        for (OreStock stock : stocks.values()) {
            if (stock.getSourceBlock() == block) return stock;
        }
        return null;
    }

    public double getIndexAverage(String tier) {
        List<OreStock> list = getByTier(tier);
        if (list.isEmpty()) return 0;
        double sum = 0;
        for (OreStock s : list) sum += s.getCurrentPrice();
        return sum / list.size();
    }

    public double getMiningRewardPercent() {
        return miningRewardPercent;
    }

    /**
     * Har X second baad chalta hai - saare stocks ki price update karta hai.
     */
    public void tick() {
        for (OreStock stock : stocks.values()) {
            double volatility = volatilityByTier.getOrDefault(stock.getTier(), 0.03);
            stock.updatePrice(volatility);
        }
    }
}
