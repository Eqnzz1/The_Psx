package com.orestock.market;

import org.bukkit.Material;

import java.util.LinkedList;

/**
 * Ek OreStock ek single "share" (jaise COAL, DIAMOND, EMERALD) ko represent karta hai.
 * Isme current price, base price, tier aur price history store hoti hai.
 */
public class OreStock {

    private final String key;
    private final String displayName;
    private final Material material;
    private final Material sourceBlock; // null ho sakta hai agar mining se nahi milta
    private final String tier; // common / rare / best
    private final double basePrice;

    private double currentPrice;
    private int buyVolume = 0;
    private int sellVolume = 0;

    private final LinkedList<Double> history = new LinkedList<>();
    private final int historyLength;

    public OreStock(String key, String displayName, Material material, Material sourceBlock,
                     String tier, double basePrice, int historyLength) {
        this.key = key;
        this.displayName = displayName;
        this.material = material;
        this.sourceBlock = sourceBlock;
        this.tier = tier;
        this.basePrice = basePrice;
        this.currentPrice = basePrice;
        this.historyLength = historyLength;
        this.history.add(basePrice);
    }

    public String getKey() { return key; }
    public String getDisplayName() { return displayName; }
    public Material getMaterial() { return material; }
    public Material getSourceBlock() { return sourceBlock; }
    public String getTier() { return tier; }
    public double getBasePrice() { return basePrice; }
    public double getCurrentPrice() { return currentPrice; }
    public LinkedList<Double> getHistory() { return history; }

    public void addBuyVolume(int amount) { buyVolume += amount; }
    public void addSellVolume(int amount) { sellVolume += amount; }

    /**
     * Price ko update karta hai buy/sell pressure ke hisaab se, phir volumes reset kar deta hai.
     */
    public void updatePrice(double volatility) {
        int totalVolume = buyVolume + sellVolume;
        if (totalVolume > 0) {
            double pressure = (double) (buyVolume - sellVolume) / (double) Math.max(totalVolume, 1);
            // extra: raw volume bhi thoda asar dalta hai (zyada volume = zyada movement)
            double volumeFactor = Math.min(1.0, totalVolume / 20.0);
            double change = pressure * volatility * volumeFactor;
            currentPrice = currentPrice * (1 + change);
        } else {
            // koi trading activity nahi hui -> price thoda base price ki taraf drift karega
            double drift = (basePrice - currentPrice) * 0.01;
            currentPrice += drift;
        }

        // price kabhi bahut kam na ho jaye
        double floor = basePrice * 0.15;
        if (currentPrice < floor) currentPrice = floor;

        history.add(currentPrice);
        if (history.size() > historyLength) history.removeFirst();

        buyVolume = 0;
        sellVolume = 0;
    }
}
