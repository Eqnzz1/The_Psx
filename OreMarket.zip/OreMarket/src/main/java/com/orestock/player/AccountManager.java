package com.orestock.player;

import com.orestock.OreMarketPlugin;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class AccountManager {

    private final OreMarketPlugin plugin;
    private final Map<UUID, PlayerAccount> accounts = new HashMap<>();
    private final File dataFolder;

    public AccountManager(OreMarketPlugin plugin) {
        this.plugin = plugin;
        this.dataFolder = new File(plugin.getDataFolder(), "playerdata");
        if (!dataFolder.exists()) dataFolder.mkdirs();
    }

    public PlayerAccount getAccount(UUID uuid) {
        if (accounts.containsKey(uuid)) return accounts.get(uuid);
        PlayerAccount account = loadAccount(uuid);
        accounts.put(uuid, account);
        return account;
    }

    private PlayerAccount loadAccount(UUID uuid) {
        File file = new File(dataFolder, uuid.toString() + ".yml");
        double startingBalance = plugin.getConfig().getDouble("starting-balance", 100.0);

        if (!file.exists()) {
            return new PlayerAccount(uuid, startingBalance);
        }

        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        double balance = yaml.getDouble("balance", startingBalance);
        PlayerAccount account = new PlayerAccount(uuid, balance);

        if (yaml.isConfigurationSection("portfolio")) {
            for (String key : yaml.getConfigurationSection("portfolio").getKeys(false)) {
                int amount = yaml.getInt("portfolio." + key, 0);
                if (amount > 0) account.addShares(key, amount);
            }
        }
        return account;
    }

    public void saveAccount(UUID uuid) {
        PlayerAccount account = accounts.get(uuid);
        if (account == null) return;

        File file = new File(dataFolder, uuid.toString() + ".yml");
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("balance", account.getBalance());
        for (Map.Entry<String, Integer> entry : account.getPortfolio().entrySet()) {
            yaml.set("portfolio." + entry.getKey(), entry.getValue());
        }

        try {
            yaml.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Player data save nahi ho payi: " + uuid);
        }
    }

    public void saveAll() {
        for (UUID uuid : accounts.keySet()) {
            saveAccount(uuid);
        }
    }

    public boolean isLoaded(UUID uuid) {
        return accounts.containsKey(uuid);
    }
}
