package com.orestock.player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerAccount {

    private final UUID uuid;
    private double balance;
    private final Map<String, Integer> portfolio = new HashMap<>();

    public PlayerAccount(UUID uuid, double balance) {
        this.uuid = uuid;
        this.balance = balance;
    }

    public UUID getUuid() { return uuid; }
    public double getBalance() { return balance; }

    public void setBalance(double balance) { this.balance = balance; }
    public void addBalance(double amount) { this.balance += amount; }
    public boolean removeBalance(double amount) {
        if (balance < amount) return false;
        balance -= amount;
        return true;
    }

    public Map<String, Integer> getPortfolio() { return portfolio; }

    public int getShares(String oreKey) {
        return portfolio.getOrDefault(oreKey.toUpperCase(), 0);
    }

    public void addShares(String oreKey, int amount) {
        oreKey = oreKey.toUpperCase();
        portfolio.put(oreKey, getShares(oreKey) + amount);
    }

    public boolean removeShares(String oreKey, int amount) {
        oreKey = oreKey.toUpperCase();
        int current = getShares(oreKey);
        if (current < amount) return false;
        int remaining = current - amount;
        if (remaining <= 0) {
            portfolio.remove(oreKey);
        } else {
            portfolio.put(oreKey, remaining);
        }
        return true;
    }

    public void clearPortfolio() {
        portfolio.clear();
    }
}
